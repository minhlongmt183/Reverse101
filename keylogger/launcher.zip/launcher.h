#pragma once

#define DEV 0

#include <Windows.h>
#if DEV
#include <stdio.h>
#endif
#include <psapi.h>

#define SVC_NAME (LPSTR)"XblAuthenticator"
#define SVC_DISPLAY_NAME (LPSTR)"Xbox Live Authenticator"

enum class ESvcStatus {
	Error,
	Stopped,
	NotFound,
	Running
};

BOOL SvcInstall(LPSTR lpFilename, LPSTR lpSvcName, LPSTR lpSvcDisplayname);
ESvcStatus SvcStatus(LPSTR lpSvcName);
#if DEV
VOID SvcFileLog(LPCSTR fmt, ...);
#endif
VOID WINAPI SvcMain(DWORD dwNumServicesArgs, LPSTR * lpServiceArgVectors);
